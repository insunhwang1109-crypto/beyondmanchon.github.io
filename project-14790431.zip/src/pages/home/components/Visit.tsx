const ENTRANCE =
  'https://storage.helloreaddy.io/project_files/5abe74fb-6b4c-4288-bc63-99119885c1e5/d8ab5f4a-ef14-4f93-93a3-94963de8012c_compressed_3.webp';

export default function Visit() {
  return (
    <section className="panel" data-side="left" id="visit">
      <img className="panel-bg" data-parallax="0.32" alt="비욘드 잉글리쉬 수성만촌센터 입구와 BE 간판" title="비욘드 잉글리쉬 수성만촌센터 오시는 길"
        src={ENTRANCE} />
      <div className="panel-veil"></div>
      <div className="panel-copy" data-parallax="-0.08">
        <p className="stamp" data-reveal>상담 안내</p>
        <h2 data-reveal>수성만촌센터에서<br />만나요.</h2>
        <p className="sub" data-reveal>무료 레벨 테스트 후 아이에게 맞는 반을 안내해 드립니다. 편한 시간에 방문 상담을 예약해 주세요.</p>
        <ul className="chips" data-reveal>
          <li>평일 14:00 – 22:00</li><li>주말 09:00 – 21:00</li><li>방문 상담 가능</li>
        </ul>
        <div className="flex flex-wrap gap-3" data-reveal>
          <a className="btn" href="#location">상담 예약하기 <i className="ri-arrow-right-line"></i></a>
          <a className="btn ghost" href="tel:050713967869"><i className="ri-phone-line"></i> 전화 문의</a>
        </div>
      </div>
    </section>
  );
}