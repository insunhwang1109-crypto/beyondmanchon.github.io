const items = [
  { icon: 'ri-customer-service-2-line', label: '상담 문의', value: '0507-1396-7869', note: '전화 상담 환영' },
  { icon: 'ri-time-line', label: '평일 운영', value: '14:00 – 22:00', note: '월 – 금요일' },
  { icon: 'ri-calendar-check-line', label: '주말 운영', value: '09:00 – 21:00', note: '토 · 일요일' },
];

export default function InfoPanel() {
  return (
    <section className="infobar" aria-label="상담 및 운영 시간 안내">
      <div className="infobar-inner">
        {items.map((it) => (
          <div className="info-cell" data-reveal key={it.label}>
            <span className="info-ico"><i className={it.icon}></i></span>
            <div>
              <p className="stamp" style={{ color: 'var(--muted)' }}>{it.label}</p>
              <p className="text-base font-semibold mt-1">{it.value}</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{it.note}</p>
            </div>
          </div>
        ))}
        <a className="btn info-cta" href="#visit">실시간 상담 신청 <i className="ri-arrow-right-line"></i></a>
      </div>
    </section>
  );
}