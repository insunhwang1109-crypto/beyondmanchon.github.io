const systems = [
  {
    icon: 'ri-book-open-line',
    tag: 'Attitude',
    t: '학습 태도 관리',
    d: '수업 전 예습과 수업 후 복습 루틴을 함께 만들어 스스로 공부하는 습관을 길러 줍니다.',
  },
  {
    icon: 'ri-focus-3-line',
    tag: 'Focus',
    t: '집중적인 학습 관리',
    d: '소규모 정원과 매 수업 피드백으로 아이 한 명 한 명의 이해도를 꼼꼼하게 확인합니다.',
  },
  {
    icon: 'ri-award-line',
    tag: 'Practice',
    t: '실전과 같은 시험 관리',
    d: '정기 평가와 모의 시험으로 실전 감각을 키우고 결과를 학부모님과 투명하게 공유합니다.',
  },
];

export default function Curriculum() {
  return (
    <section className="section" id="curriculum">
      <div className="section-head" data-reveal>
        <p className="stamp">체계적인 관리</p>
        <h2 className="section-title">체계적인 <em className="accent">커리큘럼</em>으로<br />성적을 관리합니다.</h2>
        <p className="section-sub">맞춤형 수업에 의한 안정적인 학생 성적 관리 — 태도부터 실전까지 세 단계로 관리합니다.</p>
      </div>

      <div className="sys-grid">
        {systems.map((s) => (
          <article className="sys-card" data-reveal key={s.t}>
            <div className="sys-ico"><i className={s.icon}></i></div>
            <span className="sys-tag">{s.tag}</span>
            <h3 className="text-lg font-semibold mt-2">{s.t}</h3>
            <p className="text-sm mt-2 leading-relaxed" style={{ color: 'var(--muted)' }}>{s.d}</p>
          </article>
        ))}
      </div>
    </section>
  );
}