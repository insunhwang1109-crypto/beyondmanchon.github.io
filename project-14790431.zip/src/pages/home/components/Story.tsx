export default function Story() {
  return (
    <section className="panel" data-side="right" id="story">
      <img className="panel-bg" data-parallax="0.32" alt="비욘드 잉글리쉬에서 영어 원서를 읽는 학생들" title="비욘드 잉글리쉬 수성만촌센터 학부모 후기"
        src="https://readdy.ai/api/search-image?query=Korean%20elementary%20students%20reading%20English%20picture%20books%20together%20at%20a%20wooden%20table%20in%20a%20warm%20library%2C%20right%20side%20of%20frame%20in%20deep%20dark%20shadow%2C%20soft%20crimson%20accent%20lighting%2C%20cinematic%20editorial%20photograph%2C%20no%20text&width=2400&height=1350&seq=be-proof-students&orientation=landscape" />
      <div className="panel-veil"></div>
      <div className="panel-copy" data-parallax="-0.08">
        <p className="stamp" data-reveal>학부모 후기</p>
        <h2 data-reveal>학부모가<br />직접 <em className="accent">말합니다</em>.</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3 w-full text-left">
          {[
            ['4.9', '학부모 만족도 평균 (설문 기준)'],
            ['8년', '수성만촌센터 운영 기간'],
            ['“영어 책을 먼저 찾는 아이가 됐어요.” — 만촌동 학부모님', ''],
          ].map(([n, d]) => (
            <div className="card" data-reveal key={n}>
              <p className={d ? 'stat-num' : 'text-sm leading-relaxed italic'}>{n}</p>
              {d && <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{d}</p>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}