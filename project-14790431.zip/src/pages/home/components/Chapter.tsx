const VIDEO = 'https://static.readdy.ai/video/b971e92b148878d2d59af13c8fbf5997/577b4a9458721cfc60c61b6816f8353e.mp4';

export default function Chapter() {
  return (
    <section className="chapter" data-video={VIDEO} data-label="Beyond English" style={{ ['--beat-count' as string]: 4 }}>
      <div className="stage">
        <div className="veil" aria-hidden="true"></div>
        <div className="veil veil-light" aria-hidden="true"></div>

        <div className="beat" data-from="0" data-to=".2667" data-pos="bottom" data-depth="soft" data-tone="dark" data-motion="track" id="overview">
          <p className="stamp">01 · Beyond English</p>
          <h1 className="sr-only">비욘드 잉글리쉬 수성만촌센터 — 아이의 영어가 시작되는 곳</h1>
          <h2 data-split="lines">아이의 영어,<br />여기서 <em className="accent">시작</em>됩니다.</h2>
          <p className="sub">비욘드 잉글리쉬 수성만촌센터에서 영어가 즐거워지는 순간을 만나보세요.</p>
        </div>

        <div className="beat" data-from=".2667" data-to=".4667" data-pos="bottom" data-depth="soft" data-tone="dark" data-motion="rise" id="craft">
          <p className="stamp">02 · 커리큘럼</p>
          <h2 data-split="lines">읽고, 말하고,<br />스스로 <em className="accent">성장</em>합니다.</h2>
          <p className="sub">연령과 실력에 맞춘 단계별 수업으로 네 가지 영어 능력을 함께 키웁니다.</p>
          <ul className="points">
            <li>연령별 맞춤 반 편성</li>
            <li>원서 읽기·토론</li>
            <li>정기 학부모 상담</li>
          </ul>
        </div>

        <div className="beat" data-from=".4667" data-to=".7333" data-pos="bottom" data-depth="soft" data-tone="light" data-motion="zoom" id="promise">
          <p className="stamp">03 · 약속</p>
          <h2 data-split="lines">영어가 <em className="accent">즐거워</em>지는 순간</h2>
        </div>

        <div className="beat" data-from=".7333" data-to="1" data-pos="bottom" data-depth="soft" data-tone="dark" data-motion="drift" id="begin">
          <p className="stamp">04 · 상담 안내</p>
          <h2 data-split="lines">우리 아이에게 맞는 수업,<br /><em className="accent">상담</em>으로 확인하세요.</h2>
          <p className="sub">무료 레벨 테스트와 1:1 상담을 수성만촌센터에서 진행합니다.</p>
          <div className="cta-row">
            <a className="btn" href="#visit">상담 신청하기 <i className="ri-arrow-right-line"></i></a>
          </div>
        </div>

        <div className="scroll-cue" aria-hidden="true"><span></span>스크롤해서 보기</div>
      </div>
    </section>
  );
}