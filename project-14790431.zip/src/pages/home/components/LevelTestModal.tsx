import { useState, type FormEvent } from 'react';
import PrivacyPolicyModal from '@/pages/home/components/PrivacyPolicyModal';

const SUBMIT_URL = 'https://readdy.ai/api/form/db1gj9om252sfkho1sv0';

const GRADES = [
  '초등 1학년', '초등 2학년', '초등 3학년', '초등 4학년', '초등 5학년', '초등 6학년',
  '중등 1학년', '중등 2학년', '중등 3학년', '기타 / 미취학',
];

const TIMES = [
  '평일 오후 (14:00 – 17:00)',
  '평일 저녁 (17:00 – 21:00)',
  '토요일 오전 (10:00 – 12:00)',
  '토요일 오후 (12:00 – 16:00)',
];

type Props = { onClose: () => void };

export default function LevelTestModal({ onClose }: Props) {
  const [status, setStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  const [formError, setFormError] = useState('');
  const [policyOpen, setPolicyOpen] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);

    // Reserve field check: silently treat as success to deter bots.
    const trap = String(data.get('website_alt') ?? '').trim();
    if (trap) {
      setStatus('done');
      form.reset();
      return;
    }
    data.delete('website_alt');

    setStatus('sending');
    setFormError('');

    try {
      const body = new URLSearchParams();
      data.forEach((value, key) => {
        if (typeof value === 'string' && value.trim() !== '') body.append(key, value);
      });

      const response = await fetch(SUBMIT_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
      });

      const responseText = await response.text();
      let parsed: { code?: string; message?: string; meta?: { message?: string; detail?: string } } | null = null;
      try {
        parsed = JSON.parse(responseText);
      } catch {
        parsed = null;
      }

      const serverMsg = parsed?.meta?.message || parsed?.message || parsed?.meta?.detail || responseText || '';
      const isSpam = typeof serverMsg === 'string' && serverMsg.toLowerCase().includes('spam');

      if (!response.ok || parsed?.code !== 'OK' || isSpam) {
        setStatus('error');
        setFormError(serverMsg || '신청서를 보내지 못했어요. 잠시 후 다시 시도해 주세요.');
        return;
      }

      setStatus('done');
      form.reset();
    } catch {
      setStatus('error');
      setFormError('네트워크 오류로 신청서를 보내지 못했어요. 잠시 후 다시 시도해 주세요.');
    }
  }

  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label="무료 레벨 테스트 신청서">
        <div className="flex items-start justify-between gap-6">
          <div>
            <p className="stamp">상담 안내</p>
            <h3 className="text-xl font-semibold mt-2">무료 레벨 테스트 신청</h3>
          </div>
          <button type="button" className="modal-x" onClick={onClose} aria-label="닫기">
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>

        {status === 'done' ? (
          <div className="flex flex-col items-center text-center gap-3 py-10">
            <span className="info-ico" style={{ width: 56, height: 56, fontSize: 26 }}>
              <i className="ri-check-line"></i>
            </span>
            <p className="text-lg font-semibold">신청이 접수됐어요.</p>
            <p className="text-sm leading-relaxed" style={{ color: 'var(--muted)' }}>
              담당 선생님이 확인 후 편한 시간에 연락드릴게요.<br />감사합니다.
            </p>
            <button type="button" className="btn mt-2" onClick={onClose}>닫기</button>
          </div>
        ) : (
          <form id="level-test-form" data-readdy-form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-5">
            <div className="form-row">
              <div className="form-field">
                <label htmlFor="lt-student">학생 이름</label>
                <input id="lt-student" name="student_name" type="text" required placeholder="예) 김민준" />
              </div>
              <div className="form-field">
                <label htmlFor="lt-grade">학년</label>
                <select id="lt-grade" name="grade" defaultValue="" required>
                  <option value="" disabled>학년을 선택해 주세요</option>
                  {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-field">
                <label htmlFor="lt-parent">학부모 성함</label>
                <input id="lt-parent" name="parent_name" type="text" required placeholder="예) 이서연" />
              </div>
              <div className="form-field">
                <label htmlFor="lt-phone">연락처</label>
                <input id="lt-phone" name="phone" type="tel" required placeholder="010-0000-0000" />
              </div>
            </div>

            <div className="form-field">
              <label htmlFor="lt-email">이메일</label>
              <input id="lt-email" name="email" type="email" required placeholder="example@email.com" />
            </div>

            <div className="form-field">
              <label htmlFor="lt-time">희망 방문 시간</label>
              <select id="lt-time" name="preferred_time" defaultValue="" required>
                <option value="" disabled>희망 시간대를 선택해 주세요</option>
                {TIMES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>

            <div className="form-field">
              <label htmlFor="lt-message">문의 내용 (선택)</label>
              <textarea id="lt-message" name="message" rows={3} maxLength={500} placeholder="아이의 영어 학습 상황이나 궁금한 점을 적어주세요. (최대 500자)" />
            </div>

            <div className="form-consent-wrap">
              <label className="form-consent">
                <input id="lt-privacy" name="privacy_consent" type="checkbox" value="동의" required />
                <span>
                  <strong>(필수)</strong> 개인정보 수집·이용에 동의합니다.
                  <em className="form-consent-note">수집 항목: 학생 이름·학년, 학부모 성함·연락처·이메일 / 이용 목적: 레벨 테스트 안내 및 상담 / 보유 기간: 상담 완료 후 6개월</em>
                </span>
              </label>
              <button type="button" className="form-consent-more" onClick={() => setPolicyOpen(true)}>
                <i className="ri-file-text-line"></i> 개인정보 처리방침 전문 보기
              </button>
            </div>

            <div className="form-note-aux" aria-hidden="true">
              <label htmlFor="lt-website-alt">Website</label>
              <input
                id="lt-website-alt"
                name="website_alt"
                type="text"
                tabIndex={-1}
                autoComplete="off"
                readOnly
              />
            </div>

            {status === 'error' && (
              <p className="form-error" role="alert">{formError}</p>
            )}

            <button type="submit" className="btn" disabled={status === 'sending'} style={{ justifyContent: 'center' }}>
              {status === 'sending' ? '보내는 중…' : '무료 레벨 테스트 신청하기'}
            </button>
            <p className="text-xs text-center" style={{ color: 'var(--muted)' }}>
              남겨주신 정보는 상담 목적으로만 사용돼요.
            </p>
          </form>
        )}
      </div>

      {policyOpen && <PrivacyPolicyModal onClose={() => setPolicyOpen(false)} />}
    </div>
  );
}