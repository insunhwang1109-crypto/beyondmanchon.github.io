import { useState } from 'react';
import { timetableWeekday, timetableWeekend } from '@/mocks/timetable';

const steps = [
  { n: '01', t: '상담 예약', d: '전화 또는 방문으로 편한 상담 시간을 예약합니다.' },
  { n: '02', t: '무료 레벨 테스트', d: '현재 영어 실력을 진단하고 강점을 확인합니다.' },
  { n: '03', t: '반 편성 안내', d: '실력과 연령에 맞춰 가장 알맞은 반을 배정합니다.' },
  { n: '04', t: '수강 등록', d: '수강 신청 후 첫 수업을 시작합니다.' },
];

export default function Admissions() {
  const [tab, setTab] = useState<'weekday' | 'weekend'>('weekday');
  const rows = tab === 'weekday' ? timetableWeekday : timetableWeekend;

  return (
    <section className="section tint" id="admission">
      <div className="section-head" data-reveal>
        <p className="stamp">입학 안내</p>
        <h2 className="section-title">입학 절차와 <em className="accent">시간표</em>를<br />한눈에 확인하세요.</h2>
        <p className="section-sub">네 단계의 간단한 절차만 거치면 아이에게 꼭 맞는 수업을 시작할 수 있습니다.</p>
      </div>

      <div className="split">
        <div className="panelcard" data-reveal>
          <p className="stamp">Admission Guide &amp; Procedure</p>
          <h3 className="text-xl font-semibold mt-3">입학 안내 및 절차</h3>
          <p className="text-sm mt-2" style={{ color: 'var(--muted)' }}>입학부터 수강 등록까지 순서대로 안내해 드립니다.</p>
          <ol className="steps">
            {steps.map((s) => (
              <li key={s.n}>
                <span className="step-num">{s.n}</span>
                <div>
                  <p className="font-semibold text-sm">{s.t}</p>
                  <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{s.d}</p>
                </div>
              </li>
            ))}
          </ol>
          <a className="btn ghost mt-6" href="#visit" style={{ alignSelf: 'flex-start' }}>상담 예약하기 <i className="ri-arrow-right-line"></i></a>
        </div>

        <div className="panelcard accent" data-reveal>
          <p className="stamp">Check the Timetable</p>
          <h3 className="text-xl font-semibold mt-3">시간표 확인</h3>
          <p className="text-sm mt-2 subtle" style={{ color: 'color-mix(in srgb, var(--bg) 72%, transparent)' }}>요일에 따라 수업 시간이 달라요.</p>
          <div className="tabs mt-4">
            <button type="button" className={tab === 'weekday' ? 'on' : ''} onClick={() => setTab('weekday')}>평일</button>
            <button type="button" className={tab === 'weekend' ? 'on' : ''} onClick={() => setTab('weekend')}>주말</button>
          </div>
          <table className="tt">
            <thead>
              <tr><th>시간</th><th>수업</th><th>담당</th></tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.time}><td>{r.time}</td><td>{r.cls}</td><td>{r.teacher}</td></tr>
              ))}
            </tbody>
          </table>
          <p className="text-xs mt-3" style={{ color: 'color-mix(in srgb, var(--bg) 68%, transparent)' }}>※ 시간표는 반 편성에 따라 달라질 수 있습니다.</p>
        </div>
      </div>
    </section>
  );
}