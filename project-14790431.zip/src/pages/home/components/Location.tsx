import { useState } from 'react';
import LevelTestModal from '@/pages/home/components/LevelTestModal';

export default function Location() {
  const [applyOpen, setApplyOpen] = useState(false);

  return (
    <section className="location" id="location">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <div className="flex flex-col gap-4" data-reveal>
          <p className="stamp">06 — 오시는 길</p>
          <h2 className="footer-line">수성만촌센터로<br />오시는 길을 <em className="accent">안내</em>합니다.</h2>
          <div className="flex flex-col gap-3 text-sm mt-2">
            <p className="flex items-start gap-3"><i className="ri-map-pin-2-line text-lg" style={{ color: 'var(--accent2)' }}></i><span>대구 수성구 교학로19길 36 2층</span></p>
            <p className="flex items-start gap-3"><i className="ri-subway-line text-lg" style={{ color: 'var(--accent2)' }}></i><span>담티역 2번 출구에서 860m</span></p>
            <p className="flex items-start gap-3"><i className="ri-time-line text-lg" style={{ color: 'var(--accent2)' }}></i><span>평일 14:00 – 21:00 · 토요일 10:00 – 16:00 · 일요일 휴무</span></p>
            <p className="flex items-start gap-3"><i className="ri-phone-line text-lg" style={{ color: 'var(--accent2)' }}></i><span>0507-1396-7869</span></p>
          </div>
          <button type="button" className="btn" onClick={() => setApplyOpen(true)} style={{ alignSelf: 'flex-start', marginTop: 8 }}>무료 레벨 테스트 신청 <i className="ri-arrow-right-line"></i></button>
        </div>
        <div className="flex flex-col gap-4" data-reveal>
          <div className="map-frame">
            <iframe
              title="비욘드 잉글리쉬 수성만촌센터 위치"
              src="https://www.google.com/maps?q=%EB%8C%80%EA%B5%AC%20%EC%88%98%EC%84%B1%EA%B5%AC%20%EA%B5%90%ED%95%99%EB%A1%9C19%EA%B8%B8%2036&output=embed"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
          <a
            className="btn ghost"
            href="https://map.naver.com/p/search/%EB%B9%84%EC%9A%9D%EB%93%9C%EC%9E%89%EA%B8%80%EB%A6%AC%EC%89%AC%20%EC%88%98%EC%84%B1%EB%A7%8C%EC%B4%8C%20%ED%94%84%EB%A6%AC%EB%AF%B8%EC%97%84%EC%84%BC%ED%84%B0"
            target="_blank"
            rel="noopener noreferrer"
            style={{ alignSelf: 'flex-start' }}
          >
            <i className="ri-navigation-line"></i> 네이버 지도에서 길찾기
          </a>
        </div>
      </div>
      {applyOpen && <LevelTestModal onClose={() => setApplyOpen(false)} />}
    </section>
  );
}