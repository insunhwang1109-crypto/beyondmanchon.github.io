const LOUNGE =
  'https://storage.helloreaddy.io/project_files/5abe74fb-6b4c-4288-bc63-99119885c1e5/b78f2bcd-4fb3-45e5-b1d5-e7ac1c9215ae_compressed_4.webp';

export default function Panels() {
  return (
    <>
      <section className="panel manifesto" id="belief">
        <span className="panel-accent rings" aria-hidden="true" data-parallax="0.55"></span>
        <p className="manifesto-text" data-words>
          우리는 영어를 점수가 아니라 <em className="accent">자신감</em>으로 배웁니다. 매일의 작은 성취가 아이의 <em className="accent">목소리</em>를 바꾸고, 그 변화는 오래갑니다.
        </p>
      </section>

      <section className="panel" data-side="right" id="center">
        <img className="panel-bg" data-parallax="0.32" alt="비욘드 잉글리쉬 수성만촌센터 라운지 전경" title="비욘드 잉글리쉬 수성만촌센터 센터 소개"
          src={LOUNGE} />
        <div className="panel-veil"></div>
        <div className="panel-copy" data-parallax="-0.08">
          <p className="stamp" data-reveal>센터 소개</p>
          <h2 data-reveal>아이가 머물고<br />싶은 <em className="accent">공간</em>.</h2>
          <p className="sub" data-reveal>탁 트인 창가 열람 공간과 편안한 상담실, 아이 눈높이에 맞춘 교재 라이브러리를 갖췄습니다. 수성만촌센터에서 직접 확인해 보세요.</p>
          <ul className="chips" data-reveal>
            <li>원서 라이브러리</li><li>개별 상담실</li><li>쾌적한 열람 공간</li><li>소규모 정원</li>
          </ul>
        </div>
      </section>

      <section className="panel" data-side="left" id="program">
        <img className="panel-bg" data-parallax="0.32" alt="비욘드 잉글리쉬 수업이 이루어지는 영어 교실" title="비욘드 잉글리쉬 수성만촌센터 수업 프로그램"
          src="https://readdy.ai/api/search-image?query=Bright%20warm%20English%20academy%20classroom%20with%20small%20wooden%20tables%2C%20colorful%20picture%20books%20and%20flashcards%2C%20soft%20afternoon%20light%20through%20a%20large%20window%2C%20left%20side%20falling%20into%20deep%20dark%20oxblood%20shadow%2C%20cinematic%20editorial%20photograph%2C%20no%20text&width=2400&height=1350&seq=be-program-class&orientation=landscape" />
        <div className="panel-veil"></div>
        <div className="panel-copy" data-parallax="-0.08">
          <p className="stamp" data-reveal>수업 프로그램</p>
          <h2 data-reveal>실력이 쌓이는<br /><em className="accent">수업</em> 설계.</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
            {[
              ['ri-book-open-line', '파닉스·기초', '소리와 글자의 규칙을 익혀 읽기의 첫걸음을 뗍니다.'],
              ['ri-chat-smile-2-line', '원서 읽기·토론', '짧은 원서를 함께 읽고 자기 생각을 영어로 말합니다.'],
              ['ri-mic-line', '스피킹·발표', '실생활 주제로 역할극과 발표를 반복해 자신감을 키웁니다.'],
              ['ri-line-chart-line', '내신·시험 대비', '문법과 독해를 정리해 학교 성적으로 연결합니다.'],
            ].map(([icon, t, d]) => (
              <div className="card" data-reveal key={t}>
                <div className="w-8 h-8 flex items-center justify-center mb-2" style={{ color: 'var(--accent2)' }}><i className={`${icon} text-xl`}></i></div>
                <p className="font-semibold text-sm mb-1">{t}</p>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--muted)' }}>{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}