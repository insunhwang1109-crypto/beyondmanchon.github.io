type Props = { onClose: () => void };

export default function PrivacyPolicyModal({ onClose }: Props) {
  return (
    <div className="policy-back" onClick={onClose}>
      <div className="policy-card" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label="개인정보 처리방침">
        <div className="flex items-start justify-between gap-6">
          <div>
            <p className="stamp">안내</p>
            <h4 className="text-lg font-semibold mt-2">개인정보 수집·이용 동의</h4>
          </div>
          <button type="button" className="modal-x" onClick={onClose} aria-label="닫기">
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>

        <ol className="policy-list">
          <li>
            <strong>1. 수집하는 개인정보 항목</strong>
            <p>필수: 학생 이름, 학년, 학부모 성함, 연락처, 이메일 &middot; 선택: 문의 내용</p>
          </li>
          <li>
            <strong>2. 개인정보의 수집·이용 목적</strong>
            <p>무료 레벨 테스트 안내 및 일정 조율, 학원 상담 및 수강 안내, 신청 접수 확인</p>
          </li>
          <li>
            <strong>3. 개인정보의 보유 및 이용 기간</strong>
            <p>상담 완료 후 6개월까지 보관한 뒤 지체 없이 파기합니다. 단, 관련 법령에 따라 보존이 필요한 경우 해당 기간 동안 보관합니다.</p>
          </li>
          <li>
            <strong>4. 동의를 거부할 권리 및 불이익</strong>
            <p>동의를 거부하실 수 있으나, 거부 시 레벨 테스트 신청 및 상담 진행이 어려울 수 있습니다.</p>
          </li>
        </ol>

        <p className="text-xs leading-relaxed mt-5" style={{ color: 'var(--muted)' }}>
          입력하신 정보는 위 목적 이외에는 사용되지 않으며, 제3자에게 제공되지 않습니다.
        </p>

        <button type="button" className="btn mt-6" style={{ justifyContent: 'center' }} onClick={onClose}>확인</button>
      </div>
    </div>
  );
}