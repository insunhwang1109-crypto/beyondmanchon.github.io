import { useState } from 'react';
import { notices } from '@/mocks/notices';

type Notice = (typeof notices)[number];

export default function Notice() {
  const [open, setOpen] = useState<Notice | null>(null);

  return (
    <section className="section tint" id="notice">
      <div className="section-head" data-reveal>
        <p className="stamp">학원 소식</p>
        <h2 className="section-title">공지사항</h2>
        <p className="section-sub">학원의 새로운 소식과 일정을 확인하세요. 제목을 클릭하면 자세한 내용을 볼 수 있습니다.</p>
      </div>

      <div className="board" data-reveal>
        {notices.map((n) => (
          <button type="button" className="board-row" key={n.id} onClick={() => setOpen(n)}>
            <span className="board-cat">{n.category}</span>
            <span className="board-title">{n.title}</span>
            <span className="board-date">{n.date}</span>
          </button>
        ))}
      </div>

      {open && (
        <div className="modal-back" onClick={() => setOpen(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
            <div className="flex items-start justify-between gap-6">
              <div>
                <span className="board-cat">{open.category}</span>
                <h3 className="text-xl font-semibold mt-3">{open.title}</h3>
                <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{open.date}</p>
              </div>
              <button type="button" className="modal-x" onClick={() => setOpen(null)} aria-label="닫기">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <p className="text-sm leading-relaxed mt-5" style={{ color: 'color-mix(in srgb, var(--text) 84%, var(--muted))' }}>{open.body}</p>
          </div>
        </div>
      )}
    </section>
  );
}