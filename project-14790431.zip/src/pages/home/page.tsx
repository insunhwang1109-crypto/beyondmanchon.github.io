import { useEffect, useState } from 'react';
import Chapter from './components/Chapter';
import InfoPanel from './components/InfoPanel';
import Panels from './components/Panels';
import Admissions from './components/Admissions';
import Curriculum from './components/Curriculum';
import Notice from './components/Notice';
import Story from './components/Story';
import Visit from './components/Visit';
import Location from './components/Location';
import PrivacyPolicyModal from './components/PrivacyPolicyModal';
import { initMotion } from './motion';

export default function Home() {
  const [solid, setSolid] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);

  useEffect(() => {
    initMotion();
    const onScroll = () => {
      const ch = document.querySelector('.chapter') as HTMLElement | null;
      setSolid(!!ch && ch.getBoundingClientRect().bottom < 80);
    };
    addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <header className={`nav ${solid ? 'is-solid' : ''}`}>
        <a href="#overview" data-progress="0" className="logo"><i className="ri-book-2-fill"></i>비욘드 잉글리쉬</a>
        <nav className="links">
          <a href="#overview" data-progress="0">학원 소개</a>
          <a href="#craft" data-progress=".2667">커리큘럼</a>
          <a href="#admission">입학 안내</a>
          <a href="#notice">공지사항</a>
          <a href="#location">오시는 길</a>
        </nav>
        <a className="btn" href="#visit" style={{ padding: '9px 16px', fontSize: 14 }}>상담 신청</a>
      </header>
      <main>
        <Chapter />
        <InfoPanel />
        <Panels />
        <Admissions />
        <Curriculum />
        <Notice />
        <Story />
        <Visit />
        <Location />
      </main>
      <footer className="footer">
        <div className="flex flex-col lg:flex-row gap-12 justify-between">
          <div data-reveal>
            <p className="footer-line">영어가 즐거워지는<br />수성만촌센터의 <em className="accent">약속</em>.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-10 text-sm">
            {[['학원', ['학원 소개', '커리큘럼', '수업 프로그램', '상담 안내']], ['안내', ['오시는 길', '입학 안내', '공지사항']], ['고객 지원', ['자주 묻는 질문', '개인정보처리방침', '이용약관']]].map(([h, ls]) => (
              <div data-reveal key={h as string} className="flex flex-col gap-2">
                <p className="stamp mb-2">{h as string}</p>
                {(ls as string[]).map((l) => (
                  l === '개인정보처리방침'
                    ? <button key={l} type="button" className="footer-link-btn" onClick={() => setPolicyOpen(true)}>{l}</button>
                    : <a key={l} href="#overview">{l}</a>
                ))}
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mt-16 pt-6 text-xs" style={{ borderTop: '1px solid color-mix(in srgb, var(--text) 10%, transparent)', color: 'var(--muted)' }}>
          <p>© 2026 비욘드 잉글리쉬 수성만촌센터. All rights reserved.</p>
          <div className="flex gap-3">
            {['ri-instagram-line', 'ri-youtube-line', 'ri-kakao-talk-fill'].map((i) => (
              <a key={i} className="social" href="#overview" aria-label={i}><i className={i}></i></a>
            ))}
          </div>
        </div>
      </footer>
      {policyOpen && <PrivacyPolicyModal onClose={() => setPolicyOpen(false)} />}
    </>
  );
}