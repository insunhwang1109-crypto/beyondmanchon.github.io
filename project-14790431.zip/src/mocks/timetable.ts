export const timetableWeekday = [
  { time: '14:00 – 15:30', cls: '파닉스·기초 A', teacher: '김OO' },
  { time: '15:40 – 17:10', cls: '원서 읽기 B', teacher: '이OO' },
  { time: '17:20 – 18:50', cls: '스피킹·발표 C', teacher: '박OO' },
  { time: '19:00 – 20:30', cls: '내신·시험 대비 D', teacher: '정OO' },
];

export const timetableWeekend = [
  { time: '09:00 – 10:30', cls: '파닉스·기초 A', teacher: '김OO' },
  { time: '10:40 – 12:10', cls: '원서 읽기 B', teacher: '이OO' },
  { time: '13:00 – 14:30', cls: '스피킹·발표 C', teacher: '박OO' },
  { time: '14:40 – 16:10', cls: '내신·시험 대비 D', teacher: '정OO' },
];